package com.sp.post.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sp.post.entity.Employee;
import com.sp.post.respositories.EmployeeRepository;
import com.sp.post.utilies.APIResponse;

@RestController
@RequestMapping("/api")
public class EmployeeController {
   @Autowired
	public EmployeeRepository employeeRespository;
	@PostMapping(path="/employee",consumes = "application/json", produces = "application/json")
	public APIResponse<Employee> insertEmployee(@RequestBody Employee employee){
		APIResponse<Employee> api=new APIResponse<>();
		employee=employeeRespository.save(employee);
		api.setPayLoad(employee);
		return api;
	}
}
