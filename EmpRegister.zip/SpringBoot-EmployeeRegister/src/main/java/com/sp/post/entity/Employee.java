package com.sp.post.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity(name="EMP_RESGISTER")
public class Employee implements Serializable {
	   @Id
	   @GeneratedValue(strategy=GenerationType.AUTO)
	   @Column(name="EMP_ID")
	   private Integer empId;
	   @Column(name="FIRSTNAME")
	   private String firstName;
	   @Column(name="LASTNAME")
	   private String lastName;
	   @Column(name="EMAIL")
	   private String email;
	   @Column(name="PHONENUMER")
	   private Long phoneNumber;
	   @Column(name="ADDRESS")
	   private String address;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	   
	   
}
