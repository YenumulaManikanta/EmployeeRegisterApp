package com.sp.post.respositories;

import org.springframework.data.repository.CrudRepository;

import com.sp.post.entity.Employee;

public interface EmployeeRepository extends CrudRepository<Employee,Integer> {

}
