package com.sp.post.utilies;

import java.util.ArrayList;
import java.util.List;



public class APIResponse<T> {
   private Status status=new Status();
   private T payLoad;
   private List ErrorInfo=new ArrayList<>();
   public APIResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}
public T getPayLoad() {
	return payLoad;
}
public void setPayLoad(T payLoad) {
	this.payLoad = payLoad;
}
public List getErrorInfo() {
	return ErrorInfo;
}
public void setErrorInfo(List errorInfo) {
	ErrorInfo = errorInfo;
}
   
   
   
}
